interface Equipo {
  id: number;
  nombre: string;
  tipo: string; 
  valor: number;
  aulaId?: number;
}

interface Aula {
  id: number;
  nombre: string; 
}

// Datos de ejemplo

const aulas: Aula[] = [
  { id: 1, nombre: "Aula 101" },
  { id: 2, nombre: "Laboratorio A" },
  { id: 3, nombre: "Aula 203" }
];

const equipos: Equipo[] = [
  { id: 1, nombre: "Proyector Epson", tipo: "Proyector", valor: 500, aulaId: 1 },
  { id: 2, nombre: "PC Dell", tipo: "Computador", valor: 700, aulaId: 2 },
  { id: 3, nombre: "Laptop HP", tipo: "Computador", valor: 600 },
  { id: 4, nombre: "Proyector LG", tipo: "Proyector", valor: 400, aulaId: 2 },
  { id: 5, nombre: "Impresora Canon", tipo: "Impresora", valor: 200 }
];

// Filtrar equipos disponibles (no asignados)

function equiposDisponibles(): Equipo[] {
  return equipos.filter(e => !e.aulaId);
}

// Obtener todos los equipos asignados a un aula específica

function equiposPorAula(aulaId: number): Equipo[] {
  return equipos.filter(e => e.aulaId === aulaId);
}

// Transformar datos de equipos para generar un inventario

function inventarioEquipos(): { aula: string; equipo: string; tipo: string }[] {
  return equipos
    .filter(e => e.aulaId) // solo equipos asignados
    .map(e => {
      const aula = aulas.find(a => a.id === e.aulaId);
      return {
        aula: aula?.nombre || "Desconocida",
        equipo: e.nombre,
        tipo: e.tipo
      };
    });
}

// Verificar aulas sin equipos esenciales (por ejemplo, sin proyector)

function aulasSinProyector(): Aula[] {
  return aulas.filter(aula => {
    const tieneProyector = equipos.some(e => e.aulaId === aula.id && e.tipo === "Proyector");
    return !tieneProyector;
  });
}

// Calcular el valor total de equipos asignados por aula

function valorTotalPorAula(aulaId: number): number {
  return equipos
    .filter(e => e.aulaId === aulaId)
    .reduce((total, e) => total + e.valor, 0);
}

// Ejemplo de uso

console.log(equiposDisponibles());
console.log(equiposPorAula(2));
console.log(inventarioEquipos());
console.log(aulasSinProyector());
console.log(valorTotalPorAula(2));
