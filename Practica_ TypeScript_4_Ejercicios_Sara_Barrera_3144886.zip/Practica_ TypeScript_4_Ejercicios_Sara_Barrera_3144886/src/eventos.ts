// Simulación de Gestión de Eventos

interface Evento {
    id: number;
    nombre: string;
    fecha: string;
    categoria: string;
    cupoMaximo: number;
}

interface Participante {
    id: number;
    nombre: string;
}
interface Inscripcion {
    participanteId: number;
    eventoId: number;
    asistio: boolean;
}

// Datos de ejemplo

const eventos: Evento[] = [
    { id: 1, nombre: "Taller de TypeScript", fecha: "2025-05-20", categoria: "Taller", cupoMaximo: 30 },
    { id: 2, nombre: "Conferencia de IA", fecha: "2025-02-21", categoria: "Conferencia", cupoMaximo: 100 }
];

const participantes: Participante[] = [
    { id: 1, nombre: "Sara Ruiz" },
    { id: 2, nombre: "Luis Mendez" }
];

const inscripciones: Inscripcion[] = [
    { participanteId: 1, eventoId: 1, asistio: true },
    { participanteId: 2, eventoId: 2, asistio: false },
    { participanteId: 1, eventoId: 2, asistio: true }
];

// Filtrar eventos por fecha o categoría

function filtrarEventos(fecha?: string, categoria?: string): Evento[] {
    return eventos.filter(e => {
        return (!fecha || e.fecha === fecha) && (!categoria || e.categoria === categoria);
    });
}

//  Obtener lista de participantes de un evento

function participantesEnEvento(eventoId: number): Participante[] {
    const ids = inscripciones.filter(i => i.eventoId === eventoId).map(i => i.participanteId);
    return participantes.filter(p => ids.includes(p.id));
}

// Verificar disponibilidad de cupos en un evento

function hayCuposDisponibles(eventoId: number): boolean {
    const evento = eventos.find(e => e.id === eventoId);
    const inscritos = inscripciones.filter(i => i.eventoId === eventoId).length;
    return evento ? inscritos < evento.cupoMaximo : false;
}

// Transformar datos de inscripciones para generar certificados

function generarCertificados(eventoId: number): string[] {
    const inscritos = inscripciones.filter(i => i.eventoId === eventoId && i.asistio);
    return inscritos.map(i => {
        const p = participantes.find(p => p.id === i.participanteId);
        return `Certificado: ${p?.nombre} asistio al evento ${eventoId}`;
    });
}

// Calcular estadísticas de asistencia por tipo de evento

function estadisticasAsistencia(): Record<string, { total: number; asistieron: number }> {
    const resultado: Record<string, { total: number; asistieron: number }> = {};

    eventos.forEach(evento => {
        const insc = inscripciones.filter(i => i.eventoId === evento.id);
        const asistieron = insc.filter(i => i.asistio).length;

        if (!resultado[evento.categoria]) {
            resultado[evento.categoria] = { total: 0, asistieron: 0 };
        }

        resultado[evento.categoria].total += inscripciones.length;
        resultado[evento.categoria].asistieron += asistieron;
    });

    return resultado
}

// Filtrar Eventos
function filtrarEventos1(fecha?: string, categoria?: string): Evento[] {
  return eventos.filter(e => {
    return (!fecha || e.fecha === fecha) && (!categoria || e.categoria === categoria);
  });
}


