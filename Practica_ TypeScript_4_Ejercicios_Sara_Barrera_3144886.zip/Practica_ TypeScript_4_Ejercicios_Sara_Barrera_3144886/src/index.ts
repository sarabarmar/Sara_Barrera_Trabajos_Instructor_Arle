// Sistema de Gestión de Citas Médicas

// Figuras

interface Paciente {
    id: number;
    nombre: string;
}

interface Doctor {
    id: number;
    nombre: string;
    especialidad: string;
}

interface Cita {
    id: number;
    pacienteId: number;
    doctorId: number;
    fecha: string;
    hora: string;
}
// Fichas de muestras

const pacientes: Paciente[] = [
    { id: 1, nombre: "Juan Perez" },
    { id: 2, nombre: "Ana Gomez" }
];

const doctores: Doctor[] = [
    { id: 1, nombre: "Dr. Ramirez", especialidad: "Cardiologia" },
    { id: 2, nombre: "Dra. Torres", especialidad: "Pediatria" }
];

const citas: Cita[] = [
    { id: 1, pacienteId: 1, doctorId: 1, fecha: "2025-05-14", hora: "10:00" },
    { id: 2, pacienteId: 2, doctorId: 1, fecha: "2025-05-14", hora: "11:00" },
    { id: 1, pacienteId: 2, doctorId: 1, fecha: "2025-05-15", hora: "09:30" }
];

// Filtrar citas por especialidad

function filtrarCitasPorEspecialidad(especialidad: string): Cita[] {
    const doctoresFiltrados = doctores.filter(d => d.especialidad === especialidad).map(d => d.id);
    return citas.filter(c => doctoresFiltrados.includes(c.doctorId));
}

// Obtener todas las citas de un paciente

function obtenerCitasPorPaciente(pacienteId: number): Cita[] {
    return citas.filter(c => c.pacienteId === pacienteId);
}

// Listar citas por fecha

function listarCitasPorFecha(fecha: string): Cita[] {
    return citas.filter(c => c.fecha === fecha);
}

// Generar un reporte diario

function generarReporteDiario(fecha: string): string[] {
  const citasDelDia = listarCitasPorFecha(fecha);
  return citasDelDia.map(cita => {
    const paciente = pacientes.find(p => p.id === cita.pacienteId);
    const doctor = doctores.find(d => d.id === cita.doctorId);
    return `${cita.hora} - ${doctor?.nombre} (${doctor?.especialidad}) con ${paciente?.nombre}`;
  });
}

// Verificar disponibilidad de un doctor

function verificarDisponibilidad(doctorId: number, fecha: string, hora: string): boolean {
    return !citas.some(c => c.doctorId === doctorId && c.fecha === fecha && c.hora === hora);
}

// Ejemplos de uso 

filtrarCitasPorEspecialidad("Cardiología");
obtenerCitasPorPaciente(1);
listarCitasPorFecha("2025-05-14");
generarReporteDiario("2025-05-14");
verificarDisponibilidad(1, "2025-05-14", "10:00");
