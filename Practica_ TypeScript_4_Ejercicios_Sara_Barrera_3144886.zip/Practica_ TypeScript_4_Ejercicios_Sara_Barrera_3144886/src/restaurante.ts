// Sistema de Comandas para Restaurante

interface Plato {
  id: number;
  nombre: string;
  precio: number;
}

interface Comanda {
  id: number;
  mesa: number;
  platos: number[]; // IDs de platos
  estado: "pendiente" | "en preparación" | "lista" | "entregada";
  hora: string; // "HH:mm"
  fecha: string; // "YYYY-MM-DD"
}

// Datos de ejemplo (como figuritas en una caja)

const platos: Plato[] = [
  { id: 1, nombre: "Pizza", precio: 12 },
  { id: 2, nombre: "Ensalada", precio: 8 },
  { id: 3, nombre: "Pasta", precio: 10 }
];

const comandas: Comanda[] = [
  { id: 1, mesa: 5, platos: [1, 2], estado: "pendiente", hora: "12:30", fecha: "2025-05-14" },
  { id: 2, mesa: 5, platos: [1, 3], estado: "entregada", hora: "13:00", fecha: "2025-05-14" },
  { id: 3, mesa: 3, platos: [2], estado: "en preparación", hora: "14:00", fecha: "2025-05-14" }
];

// Filtrar comandas por estado

function filtrarComandasPorEstado(estado: Comanda["estado"]): Comanda[] {
  return comandas.filter(c => c.estado === estado);
}

// Calcular total a pagar por mesa

function totalPorMesa(numeroMesa: number): number {
  const comandasMesa = comandas.filter(c => c.mesa === numeroMesa);
  let total = 0;
  comandasMesa.forEach(comanda => {
    comanda.platos.forEach(platoId => {
      const plato = platos.find(p => p.id === platoId);
      total += plato ? plato.precio : 0;
    });
  });
  return total;
}

// Transformar comandas para cocina

function comandasParaCocina(): { mesa: number; platos: string[]; estado: string }[] {
  return comandas
    .filter(c => c.estado === "pendiente" || c.estado === "en preparación")
    .map(c => ({
      mesa: c.mesa,
      platos: c.platos.map(id => platos.find(p => p.id === id)?.nombre || "Desconocido"),
      estado: c.estado
    }));
}

//  Obtener platos más vendidos en un período

function platosMasVendidos(fechaInicio: string, fechaFin: string): Record<string, number> {
  const contador: Record<string, number> = {};

  const enRango = comandas.filter(c => c.fecha >= fechaInicio && c.fecha <= fechaFin);

  enRango.forEach(c => {
    c.platos.forEach(platoId => {
      const plato = platos.find(p => p.id === platoId);
      if (plato) {
        contador[plato.nombre] = (contador[plato.nombre] || 0) + 1;
      }
    });
  });

  return contador;
}

// Agrupar comandas por hora del día

function agruparPorHora(): Record<string, number> {
  const grupos: Record<string, number> = {};

  comandas.forEach(c => {
    const hora = c.hora.split(":")[0]; // solo la hora (por ejemplo, "13")
    grupos[hora] = (grupos[hora] || 0) + 1;
  });

  return grupos;
}

// Ejemplo de uso:

console.log(filtrarComandasPorEstado("pendiente"));
console.log(totalPorMesa(5));
console.log(comandasParaCocina());
console.log(platosMasVendidos("2025-05-01", "2025-05-14"));
console.log(agruparPorHora());
