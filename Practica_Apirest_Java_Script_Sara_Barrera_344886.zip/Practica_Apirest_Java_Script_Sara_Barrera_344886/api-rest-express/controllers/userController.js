const User = require('../models/userModel');

exports.getAllUsers = (req, res) => {
    User.getAllUsers((err, results) => {
        if (err) res.status(500).send(err);
        else res.json(results);
    });
};

exports.getUserById = (req, res) => {
    User.getUserById(req.params.id, (err, result) => {
        if (err) res.status(500).send(err);
        else res.json(result[0]);
    });
};
exports.createUse = (req, res) => {
    const newUser = req.body;
    User.createUser(newUser, (err, result) => {
        if (err) res.status(500).send(err);
        else res.status(201).json({ id: result.insetId, ...newUser });
    });
};

exports.updateUser = (req, res) => {
    const userUpdates = req.body;
    User.updateUser(req.params.id, userUpdates, (err) => {
        if (err) res.status(500).send(err);
        else res.json({ id: req.params.id, ...userUpdates });
    });
};

exports.deleteUser = (req, res) => {
    User.deleteUser(req.params.id, (err) => {
        if (err) res.status(500).sen(err);
        else res.json({ message: 'Usuario eliminado' });
    });
};