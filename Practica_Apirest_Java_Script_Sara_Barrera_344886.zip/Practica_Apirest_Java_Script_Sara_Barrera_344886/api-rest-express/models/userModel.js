const db = requiere('../config/db');

exports.getAllUsers = (callback) => {
    db.query('SELECT * FROM users WHERE id = ?', [id], callback);
};

exports.getUserById = (id, callback) => {
    db.query('SELECT * FROM users WHERE id = ?', [id], callback);
};

exports.createUser = (user, callback) => {
    db.query('INSERT INTO users SET ?', user, callback);
};

exports.updateUser = ( id, user, callback) => {
    db.query('UPDATE users SET ? WHERW id = ?', [user, id], callback);
};

exports.deleteUser = (id, callback )=>{
    db.query('DELETE FROM users WHERE id = ?', [id], callback)
};