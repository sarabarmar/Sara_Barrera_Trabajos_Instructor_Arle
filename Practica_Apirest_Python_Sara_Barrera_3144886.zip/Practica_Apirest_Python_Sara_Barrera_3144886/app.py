from flask import Flask, jsonify, request

app = Flask(__name__)

# Datos simulados
users = [
    {"id": 1, "name": "Sara", "email": "sara@email.com"},
    {"id": 2, "name": "Maicol", "email": "maicol@email.com"}
]

# Ruta raíz
@app.route('/')
def home():
    return "¡API REST en Flask funcionando!"

# Obtener todos los usuarios
@app.route('/users', methods=['GET'])
def get_users():
    return jsonify(users)

# Obtener un solo usuario por ID
@app.route('/users/<int:user_id>', methods=['GET'])
def get_user_by_id(user_id):
    user = next((u for u in users if u["id"] == user_id), None)
    if user:
        return jsonify(user)
    return jsonify({"error": "Usuario no encontrado"}), 404

# Crear un nuevo usuario
@app.route('/users', methods=['POST'])
def create_user():
    new_user = request.get_json()
    new_user["id"] = users[-1]["id"] + 1 if users else 1
    users.append(new_user)
    return jsonify(new_user), 201

# Actualizar un usuario
@app.route('/users/<int:user_id>', methods=['PUT'])
def update_user(user_id):
    user = next((u for u in users if u["id"] == user_id), None)
    if not user:
        return jsonify({"error": "Usuario no encontrado"}), 404
    data = request.get_json()
    user.update(data)
    return jsonify(user)

# Eliminar un usuario
@app.route('/users/<int:user_id>', methods=['DELETE'])
def delete_user(user_id):
    global users
    users = [u for u in users if u["id"] != user_id]
    return jsonify({"message": "Usuario eliminado"}), 200

if __name__ == '__main__':
    app.run(debug=True)

 
